<?php
require_once 'config/config.php';
require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

try {
    // Create emoji_categories table
    $sql = "CREATE TABLE IF NOT EXISTS emoji_categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "Table 'emoji_categories' created successfully.<br>";

    // Create emojis table
    $sql = "CREATE TABLE IF NOT EXISTS emojis (
        id INT AUTO_INCREMENT PRIMARY KEY,
        emoji VARCHAR(50) NOT NULL,
        category_id INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES emoji_categories(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "Table 'emojis' created successfully.<br>";

    // Insert default categories if empty
    $stmt = $db->query("SELECT COUNT(*) FROM emoji_categories");
    if ($stmt->fetchColumn() == 0) {
        $categories = ['وجوه', 'قلوب', 'احتفال', 'زهور', 'إسلامي', 'أخرى'];
        $stmt = $db->prepare("INSERT INTO emoji_categories (name) VALUES (?)");
        foreach ($categories as $cat) {
            $stmt->execute([$cat]);
        }
        echo "Default categories inserted.<br>";
    }

    // Insert default emojis if empty
    $stmt = $db->query("SELECT COUNT(*) FROM emojis");
    if ($stmt->fetchColumn() == 0) {
        $emojis = [
            'وجوه' => ['😊', '😍', '😎', '🤗', '🥳'],
            'قلوب' => ['❤️', '💕', '💖', '💗', '💓'],
            'احتفال' => ['🎉', '🎂', '🎁', '🎈', '🎊'],
            'زهور' => ['🌹', '💐', '🌸', '🌺', '🌻'],
            'إسلامي' => ['🤲', '🕌', '🌙', '⭐', '📿'],
            'أخرى' => ['✨', '🌟', '💫', '🔥', '💯']
        ];

        $catStmt = $db->prepare("SELECT id FROM emoji_categories WHERE name = ?");
        $insertStmt = $db->prepare("INSERT INTO emojis (emoji, category_id) VALUES (?, ?)");

        foreach ($emojis as $catName => $emojiList) {
            $catStmt->execute([$catName]);
            $catId = $catStmt->fetchColumn();
            if ($catId) {
                foreach ($emojiList as $emoji) {
                    $insertStmt->execute([$emoji, $catId]);
                }
            }
        }
        echo "Default emojis inserted.<br>";
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>